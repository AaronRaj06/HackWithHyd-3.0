import { type CSSProperties, type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity,
  AlertCircle,
  ArrowRight,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleDot,
  Clock3,
  Database,
  FileText,
  GitCompareArrows,
  Layers3,
  Lightbulb,
  Menu,
  MessageSquareText,
  Network,
  Plus,
  Search,
  ServerCrash,
  Settings2,
  ShieldCheck,
  Sparkles,
  Terminal,
  TrendingUp,
  X,
  Zap,
} from 'lucide-react';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

type View = 'dashboard' | 'new-incident' | 'before-after' | 'memory';
type Severity = 'P1' | 'P2' | 'P3' | 'P4';
type Incident = {
  id: string;
  title: string;
  service: string;
  severity: Severity;
  status: 'Investigating' | 'Resolved';
  time: string;
  description: string;
};
type Memory = {
  id: string;
  title: string;
  service: string;
  severity: Severity;
  summary: string;
  lesson: string;
  hits: number;
};

const initialIncidents: Incident[] = [
  { id: 'inc-1', title: 'Elevated checkout latency', service: 'checkout-api', severity: 'P2', status: 'Investigating', time: '11 min ago', description: 'Checkout requests are timing out for a subset of EU traffic after the latest release.' },
  { id: 'inc-2', title: 'Payment webhook backlog', service: 'payments-worker', severity: 'P1', status: 'Investigating', time: '34 min ago', description: 'Webhook queue depth is climbing rapidly and retries are saturating the worker pool.' },
  { id: 'inc-3', title: 'Certificate renewal warning', service: 'edge-gateway', severity: 'P3', status: 'Resolved', time: '2 hr ago', description: 'A certificate renewal job failed once but recovered on the next scheduled attempt.' },
];

const initialMemories: Memory[] = [
  { id: 'mem-1', title: 'Checkout latency after deploy', service: 'checkout-api', severity: 'P2', summary: 'Connection pool exhaustion caused a slow cascade across regional checkout workers.', lesson: 'Check pool saturation before increasing application timeouts.', hits: 14 },
  { id: 'mem-2', title: 'Worker queue saturation', service: 'payments-worker', severity: 'P1', summary: 'A retry storm amplified a provider timeout into a full queue backlog.', lesson: 'Pause retries and protect the queue before restarting workers.', hits: 9 },
  { id: 'mem-3', title: 'Edge certificate renewal', service: 'edge-gateway', severity: 'P3', summary: 'The renewal job lacked permission to write the certificate bundle.', lesson: 'Validate secret-store access in the renewal preflight.', hits: 7 },
  { id: 'mem-4', title: '502s from upstream proxy', service: 'api-proxy', severity: 'P2', summary: 'A stale upstream target remained after a canary rollback.', lesson: 'Compare target membership with the last known healthy deploy.', hits: 11 },
  { id: 'mem-5', title: 'OOM kill in report worker', service: 'report-worker', severity: 'P1', summary: 'A large export bypassed chunking and exceeded the container memory limit.', lesson: 'Force chunked exports and alert at 75% heap utilization.', hits: 6 },
  { id: 'mem-6', title: 'Read replica lag', service: 'catalog-db', severity: 'P3', summary: 'An index build consumed replica IO and made reads drift from primary.', lesson: 'Schedule index operations outside the commerce peak window.', hits: 5 },
];

const viewMeta: Record<View, { label: string; eyebrow: string; description: string }> = {
  dashboard: { label: 'Command center', eyebrow: 'Live workspace / 04', description: 'A high-signal view of active response work and the memory your team is building.' },
  'new-incident': { label: 'New incident', eyebrow: 'Response intake / 01', description: 'Give the agent a clean signal. It will connect the symptoms to what your team already learned.' },
  'before-after': { label: 'Before vs after', eyebrow: 'Learning loop / 02', description: 'See the difference a recalled resolution makes when the next incident arrives.' },
  memory: { label: 'Agent memory', eyebrow: 'Operational memory / 03', description: 'Browse the incident patterns the agent can now recognize and reuse.' },
};

function getView(location: string): View {
  if (location === '/new-incident') return 'new-incident';
  if (location === '/before-after') return 'before-after';
  if (location === '/memory') return 'memory';
  return 'dashboard';
}

function ShellNav({ active, onNavigate, collapsed, onToggle }: { active: View; onNavigate: (view: View) => void; collapsed: boolean; onToggle: () => void }) {
  const items: { view: View; label: string; icon: typeof Activity; shortcut: string }[] = [
    { view: 'dashboard', label: 'Dashboard', icon: Activity, shortcut: 'D' },
    { view: 'new-incident', label: 'New incident', icon: AlertCircle, shortcut: 'N' },
    { view: 'before-after', label: 'Before vs after', icon: GitCompareArrows, shortcut: 'B' },
    { view: 'memory', label: 'Memory', icon: BrainCircuit, shortcut: 'M' },
  ];
  return (
    <aside className="sidebar" aria-label="Primary navigation">
      <div className="brand">
        <div className="brand-mark"><Network size={18} /></div>
        {!collapsed && <div className="brand-name">incident<span>IQ</span></div>}
      </div>
      {!collapsed && <div className="nav-label eyebrow">Workspace</div>}
      <nav className="nav-group">
        {items.map(({ view, label, icon: Icon, shortcut }) => (
          <button key={view} type="button" className={`nav-item ${active === view ? 'active' : ''}`} onClick={() => onNavigate(view)} aria-current={active === view ? 'page' : undefined} data-testid={`nav-${view}`}>
            <Icon size={17} strokeWidth={1.8} />
            {!collapsed && <><span className="nav-item-copy">{label}</span><kbd>{shortcut}</kbd></>}
          </button>
        ))}
      </nav>
      <div className="sidebar-foot">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span className="online-dot" /><span className="eyebrow">Agent online</span></div>
        {!collapsed && <div style={{ color: 'hsl(var(--muted-foreground))', fontSize: 11, lineHeight: 1.5, marginTop: 9 }}>Listening across 18 services.<br />Memory sync is up to date.</div>}
      </div>
      <button type="button" className="icon-button" style={{ marginTop: 13, alignSelf: collapsed ? 'center' : 'flex-end' }} onClick={onToggle} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} data-testid="button-toggle-sidebar">
        <Menu size={17} />
      </button>
    </aside>
  );
}

function MobileNav({ active, onNavigate }: { active: View; onNavigate: (view: View) => void }) {
  const items: { view: View; label: string; icon: typeof Activity }[] = [
    { view: 'dashboard', label: 'Dashboard', icon: Activity },
    { view: 'new-incident', label: 'New incident', icon: AlertCircle },
    { view: 'before-after', label: 'Compare', icon: GitCompareArrows },
    { view: 'memory', label: 'Memory', icon: BrainCircuit },
  ];
  return <nav className="mobile-nav" aria-label="Mobile navigation">{items.map(({ view, label, icon: Icon }) => <button type="button" key={view} className={`nav-item ${active === view ? 'active' : ''}`} onClick={() => onNavigate(view)} data-testid={`mobile-nav-${view}`}><Icon size={15} /><span className="nav-item-copy">{label}</span></button>)}</nav>;
}

function Header({ active, onNavigate, onNew }: { active: View; onNavigate: (view: View) => void; onNew: () => void }) {
  const meta = viewMeta[active];
  return (
    <>
      <header className="topbar">
        <div><div className="eyebrow">{meta.eyebrow}</div><div style={{ color: 'hsl(var(--secondary-foreground))', fontSize: 12, marginTop: 5 }}>{meta.label}</div></div>
        <div className="topbar-right">
          <button type="button" className="icon-button" onClick={() => onNavigate('memory')} aria-label="Open settings and memory" data-testid="button-open-settings"><Settings2 size={16} /></button>
          <button type="button" className="avatar" onClick={() => onNavigate('dashboard')} aria-label="Return to dashboard" data-testid="button-profile">AR</button>
          <button type="button" className="btn btn-primary" onClick={onNew} data-testid="button-header-new"><Plus size={15} /> New incident</button>
        </div>
      </header>
      <MobileNav active={active} onNavigate={onNavigate} />
    </>
  );
}

function Stats({ activeCount, resolvedCount, memories, hits }: { activeCount: number; resolvedCount: number; memories: number; hits: number }) {
  const items = [
    { id: 'stat-active', label: 'Active incidents', value: activeCount, meta: '2 need attention', icon: AlertCircle, color: 'primary' },
    { id: 'stat-resolved', label: 'Resolved today', value: resolvedCount, meta: '+18% vs last week', icon: ShieldCheck, color: 'accent' },
    { id: 'stat-memories', label: 'Memories in agent', value: memories, meta: '+3 this week', icon: BrainCircuit, color: 'primary' },
    { id: 'stat-memory-hits', label: 'Memory hits', value: hits, meta: '87% useful recall', icon: TrendingUp, color: 'accent' },
  ];
  return <div className="stats-grid">{items.map(({ id, label, value, meta, icon: Icon }) => <div className="stat-card" key={id} data-testid={id}><div className="stat-top"><span>{label}</span><div className="stat-icon"><Icon size={15} /></div></div><div className="stat-value">{value}</div><div className="stat-meta"><strong>{meta.split(' ')[0]}</strong>{meta.slice(meta.indexOf(' '))}</div></div>)}</div>;
}

function NeuralCard({ memoryCount }: { memoryCount: number }) {
  return (
    <section className="panel neural-card" data-testid="neural-memory-card">
      <div className="neural-copy"><div className="neural-count"><i /> Agent memory is learning</div><h2>{memoryCount} memories active</h2><p>The more incidents resolved, the sharper the next response becomes.</p></div>
      <svg className="network" viewBox="0 0 620 270" aria-label="Neural memory network visualization" role="img">
        <g fill="none">
          <line x1="310" y1="134" x2="106" y2="61" /><line x1="310" y1="134" x2="173" y2="209" /><line x1="310" y1="134" x2="310" y2="40" /><line x1="310" y1="134" x2="490" y2="65" /><line x1="310" y1="134" x2="480" y2="207" /><line x1="106" y1="61" x2="310" y2="40" /><line x1="173" y1="209" x2="310" y2="40" /><line x1="490" y1="65" x2="480" y2="207" /><line x1="173" y1="209" x2="480" y2="207" />
        </g>
        <circle className="core" cx="310" cy="134" r="18" /><circle cx="106" cy="61" r="8" /><circle className="teal" cx="173" cy="209" r="9" /><circle cx="310" cy="40" r="7" /><circle className="teal" cx="490" cy="65" r="9" /><circle cx="480" cy="207" r="8" /><circle cx="66" cy="145" r="5" /><circle cx="551" cy="147" r="6" />
      </svg>
    </section>
  );
}

function ActivityPanel({ incidents, onResolve }: { incidents: Incident[]; onResolve: (incident: Incident) => void }) {
  return <section className="panel"><div className="panel-header"><div><div className="panel-title">Active response</div><div className="panel-subtitle">The incidents your team is watching right now</div></div><span className="eyebrow">{incidents.filter((incident) => incident.status === 'Investigating').length} open</span></div><div className="panel-body"><div className="incident-list" id="incidents-list">{incidents.length === 0 ? <div className="empty-state"><CircleDot size={23} /><div>No active incidents</div></div> : incidents.map((incident) => <div className="incident-row" key={incident.id} data-testid={`incident-row-${incident.id}`}><span className={`severity-dot severity-${incident.severity.toLowerCase()}`} /><div className="incident-copy"><strong>{incident.title}</strong><span>{incident.service} · {incident.time}</span></div><span className="incident-state">{incident.status}</span>{incident.status === 'Investigating' && <button type="button" className="btn btn-ghost" onClick={() => onResolve(incident)} data-testid={`button-resolve-${incident.id}`}>Resolve <ChevronRight size={13} /></button>}</div>)}</div></div></section>;
}

function RecentActivity() {
  const events = [
    { title: 'Memory recalled for checkout-api', detail: 'Connection pool pattern matched', time: '8m', icon: BrainCircuit },
    { title: 'Incident resolved', detail: 'Certificate renewal warning', time: '2h', icon: Check },
    { title: 'Agent memory consolidated', detail: '3 resolution patterns indexed', time: '3h', icon: Sparkles },
    { title: 'New signal received', detail: 'payments-worker queue depth', time: '4h', icon: Activity },
  ];
  return <section className="panel"><div className="panel-header"><div><div className="panel-title">Signal stream</div><div className="panel-subtitle">What the workspace learned recently</div></div><Activity size={16} color="hsl(var(--accent))" /></div><div className="panel-body"><div className="activity-list">{events.map(({ title, detail, time, icon: Icon }) => <div className="activity-row" key={title}><div className="activity-marker"><Icon size={7} /></div><div className="activity-main"><strong>{title}</strong><span>{detail}</span></div><span className="activity-time">{time}</span></div>)}</div></div></section>;
}

function Dashboard({ incidents, memories, onNavigate, onResolve, memoryHits }: { incidents: Incident[]; memories: Memory[]; onNavigate: (view: View) => void; onResolve: (incident: Incident) => void; memoryHits: number }) {
  const active = incidents.filter((incident) => incident.status === 'Investigating').length;
  const resolved = incidents.filter((incident) => incident.status === 'Resolved').length;
  return <div className="page"><div className="page-heading fade-in-up"><div><div className="eyebrow">Tuesday · 09:42 UTC</div><h1>Good morning, Alex.</h1><p>Production is holding steady. Here is the signal worth your attention.</p></div><div className="heading-actions"><button type="button" className="btn btn-secondary" onClick={() => onNavigate('memory')} data-testid="button-view-memory"><BrainCircuit size={15} /> Browse memory</button><button type="button" className="btn btn-primary" onClick={() => onNavigate('new-incident')} data-testid="button-dashboard-new"><Plus size={15} /> New incident</button></div></div><Stats activeCount={active} resolvedCount={resolved + 7} memories={memories.length + 6} hits={memoryHits} /><div className="grid-two"><NeuralCard memoryCount={memories.length + 6} /><RecentActivity /></div><div style={{ marginTop: 15 }}><ActivityPanel incidents={incidents} onResolve={onResolve} /></div></div>;
}

function QuickFill({ onFill }: { onFill: (title: string, description: string, service: string, severity: Severity) => void }) {
  const templates = [
    { label: 'Database crash', icon: Database, title: 'Primary database unavailable', description: 'Database connections are failing across the write path. Error rate is rising in the checkout flow.', service: 'catalog-db', severity: 'P1' as Severity },
    { label: 'Memory pressure', icon: ServerCrash, title: 'OOM kills in report worker', description: 'Report worker pods are being killed after large exports. Queue age is climbing steadily.', service: 'report-worker', severity: 'P1' as Severity },
    { label: 'Latency spike', icon: Clock3, title: 'Elevated API latency', description: 'p95 latency has crossed 1.8 seconds for the API. The regression started after the latest deploy.', service: 'checkout-api', severity: 'P2' as Severity },
    { label: '502 errors', icon: Zap, title: 'Upstream 502 responses', description: 'The edge proxy is returning 502s for a subset of upstream requests in us-east-1.', service: 'api-proxy', severity: 'P2' as Severity },
    { label: 'Certificate expired', icon: ShieldCheck, title: 'Edge certificate expired', description: 'TLS handshakes are failing on one edge cluster after an automated renewal did not complete.', service: 'edge-gateway', severity: 'P3' as Severity },
  ];
  return <div className="quick-grid">{templates.map(({ label, icon: Icon, title, description, service, severity }) => <button type="button" className="quick-fill" key={label} onClick={() => onFill(title, description, service, severity)} data-testid={`button-quick-fill-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={14} /><span>{label}</span></button>)}</div>;
}

function AnalysisPanel({ submitted, title }: { submitted: boolean; title: string }) {
  return <section className="panel analysis-panel" id="analysis-result-panel" data-testid="analysis-result-panel"><div className="panel-header"><div><div className="panel-title">Agent analysis</div><div className="panel-subtitle">A focused first read, grounded in your memory</div></div>{submitted && <span className="memory-badge"><BrainCircuit size={12} /> 3 memories recalled</span>}</div><div className="panel-body">{!submitted ? <div className="empty-state"><MessageSquareText size={24} /><div>Analysis appears here after you submit an incident.</div></div> : <div className="analysis-result"><div className="memory-recall"><span className="recall-dots"><i /><i /><i /><i /></span> Recalling related resolutions…</div><div className="analysis-section"><h4>Likely path</h4><p><strong>{title}</strong> matches a known saturation pattern in the {title.toLowerCase().includes('certificate') ? 'edge gateway' : 'service dependency'} layer. Start by checking the last deploy and the nearest shared resource.</p></div><div className="analysis-section"><h4>First 10 minutes</h4><p>Confirm blast radius, pin the current good revision, and compare resource pressure against the recalled incident. Avoid a broad restart until queue and retry behavior is understood.</p></div><div className="analysis-section"><h4>Confidence</h4><p>High enough to begin with the recalled runbook. The agent will learn which hypothesis held after resolution is submitted.</p></div></div>}</div></section>;
}

function NewIncident({ onSubmit, onNavigate }: { onSubmit: (incident: Omit<Incident, 'id' | 'time' | 'status'>) => void; onNavigate: (view: View) => void }) {
  const [title, setTitle] = useState('');
  const [service, setService] = useState('checkout-api');
  const [severity, setSeverity] = useState<Severity>('P2');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submittedTitle, setSubmittedTitle] = useState('');
  const fill = (nextTitle: string, nextDescription: string, nextService: string, nextSeverity: Severity) => { setTitle(nextTitle); setDescription(nextDescription); setService(nextService); setSeverity(nextSeverity); };
  const submitIncident = (event: FormEvent) => { event.preventDefault(); if (!title.trim() || !description.trim()) return; setSubmittedTitle(title); setSubmitted(true); onSubmit({ title, service, severity, description }); };
  const barColor = severity === 'P1' ? '#ff716e' : severity === 'P2' ? '#f5aa62' : severity === 'P3' ? '#e1c768' : '#57d9ab';
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">{viewMeta['new-incident'].eyebrow}</div><h1>Start with the signal.</h1><p>Describe what is happening. IncidentIQ will surface the closest known patterns before you reach for a runbook.</p></div><button type="button" className="btn btn-secondary" onClick={() => onNavigate('before-after')} data-testid="button-see-comparison"><GitCompareArrows size={15} /> See the learning loop</button></div><div className="form-layout"><form className="panel form-panel" onSubmit={submitIncident} data-testid="form-new-incident"><div className="severity-bar" style={{ background: barColor }} /><div className="field"><label htmlFor="incident-title">What is the signal?</label><input id="incident-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="e.g. Elevated checkout latency" data-testid="input-incident-title" /></div><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><div className="field"><label htmlFor="incident-service">Affected service</label><select id="incident-service" value={service} onChange={(event) => setService(event.target.value)} data-testid="select-incident-service"><option>checkout-api</option><option>payments-worker</option><option>edge-gateway</option><option>catalog-db</option><option>report-worker</option><option>api-proxy</option></select></div><div className="field"><label htmlFor="incident-severity">Severity</label><select id="incident-severity" value={severity} onChange={(event) => setSeverity(event.target.value as Severity)} data-testid="select-incident-severity"><option value="P1">P1 · Critical</option><option value="P2">P2 · High</option><option value="P3">P3 · Moderate</option><option value="P4">P4 · Low</option></select></div></div><div className="field"><label htmlFor="incident-description">What changed?</label><textarea id="incident-description" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Include symptoms, timing, recent changes, and anything the team has already tried." maxLength={1200} data-testid="textarea-incident-description" /><div className="field-hint"><span>More signal gives better recall.</span><span>{description.length} / 1200</span></div></div><button type="submit" className="btn btn-primary" style={{ width: '100%' }} data-testid="button-submit-incident"><Sparkles size={15} /> Analyze incident <ArrowRight size={15} /></button></form><aside className="panel" style={{ padding: 20 }}><div className="panel-title" style={{ marginBottom: 5 }}>Quick fill</div><div className="panel-subtitle" style={{ marginBottom: 16 }}>Use a realistic signal to explore the workspace.</div><QuickFill onFill={fill} /><div style={{ marginTop: 24, paddingTop: 16, borderTop: '1px solid hsl(var(--border))' }}><div className="eyebrow">Tip</div><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: 11, lineHeight: 1.6, margin: '8px 0 0' }}>After you resolve this incident, its root cause and lessons become a new memory the agent can use.</p></div></aside></div><AnalysisPanel submitted={submitted} title={submittedTitle} /></div>;
}

function Comparison({ onNavigate }: { onNavigate: (view: View) => void }) {
  const [service, setService] = useState('checkout-api');
  const [description, setDescription] = useState('Checkout p95 latency is above 1.8s after the latest deploy.');
  const [ran, setRan] = useState(false);
  const quickFillCompare = () => { setService('payments-worker'); setDescription('Queue depth is growing quickly after a provider timeout. Retries are saturating workers.'); };
  const runComparison = (event: FormEvent) => { event.preventDefault(); setRan(true); };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">{viewMeta['before-after'].eyebrow}</div><h1>Memory changes the first move.</h1><p>Same signal. Two response paths. Compare the generic guess with the pattern your team has already paid to learn.</p></div><button type="button" className="btn btn-secondary" onClick={() => onNavigate('memory')} data-testid="button-open-memory-from-compare"><BrainCircuit size={15} /> Explore memories</button></div><form className="panel" style={{ padding: 18, marginBottom: 15 }} onSubmit={runComparison} data-testid="form-comparison"><div className="compare-form-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 10, alignItems: 'end' }}><div className="field" style={{ marginBottom: 0 }}><label htmlFor="compare-service">Service</label><select id="compare-service" value={service} onChange={(event) => setService(event.target.value)} data-testid="select-compare-service"><option>checkout-api</option><option>payments-worker</option><option>edge-gateway</option><option>api-proxy</option></select></div><div className="field" style={{ marginBottom: 0 }}><label htmlFor="compare-description">Incident signal</label><input id="compare-description" value={description} onChange={(event) => setDescription(event.target.value)} data-testid="input-compare-description" /></div><div style={{ display: 'flex', gap: 8 }}><button type="button" className="btn btn-secondary" onClick={quickFillCompare} data-testid="button-quick-fill-compare"><Zap size={14} /> Quick fill</button><button type="submit" className="btn btn-primary" data-testid="button-run-comparison"><GitCompareArrows size={14} /> Run comparison</button></div></div></form><div className="compare-layout" id="compare-result" data-testid="compare-result"><section className="panel compare-panel without"><div className="compare-title"><h3>Without memory</h3><span>generic response</span></div><div className="compare-content">{ran ? <><p>Check application logs, restart the affected pods, and increase the timeout if the issue persists.</p><p style={{ marginTop: 17, color: '#d9908e' }}>The response treats the symptom as isolated. It does not ask what changed or protect the retry path.</p></> : <div className="empty-state"><FileText size={23} /><div>Run the comparison to see the old path.</div></div>}</div></section><div className="compare-divider"><ChevronRight size={19} /><span>Memory<br />added</span></div><section className="panel compare-panel with"><div className="compare-particles"><i /><i /><i /><i /><i /></div><div className="compare-title"><h3>With memory</h3><span style={{ color: 'hsl(var(--accent))' }}>recalled response</span></div><div className="compare-content">{ran ? <><p>Pause the retry amplification, then compare connection-pool saturation against the remembered deploy pattern for <strong>{service}</strong>.</p><p style={{ marginTop: 17, color: 'hsl(var(--accent))' }}>The response starts with the highest-leverage guardrail and gives the team a specific hypothesis to test.</p></> : <div className="empty-state"><BrainCircuit size={23} /><div>Run the comparison to see the learned path.</div></div>}</div></section></div>{ran && <section className="panel score-bar"><div className="score-row"><span>Response quality</span><div className="score-track"><div className="score-fill bad" style={{ '--score': '28%' } as CSSProperties} /></div><span style={{ color: '#e46d6c', fontFamily: 'var(--app-font-mono)' }}>28%</span></div><div className="score-row"><span>With memory</span><div className="score-track"><div className="score-fill good" style={{ '--score': '92%' } as CSSProperties} /></div><span style={{ color: 'hsl(var(--accent))', fontFamily: 'var(--app-font-mono)' }}>92%</span></div></section>}</div>;
}

function MemoryPage({ memories, onSeed, onSearch }: { memories: Memory[]; onSeed: () => void; onSearch: (query: string) => void }) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => { const normalized = query.toLowerCase(); return memories.filter((memory) => `${memory.title} ${memory.service} ${memory.summary}`.toLowerCase().includes(normalized)); }, [memories, query]);
  const searchMemory = (value: string) => { setQuery(value); onSearch(value); };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">{viewMeta.memory.eyebrow}</div><h1>What the agent remembers.</h1><p>Every resolution becomes a reusable signal. Search the patterns, inspect the lesson, and see where recall is already helping.</p></div><button type="button" className="btn btn-primary" onClick={onSeed} data-testid="button-seed-memory"><Plus size={15} /> Seed demo memory</button></div><div className="memory-toolbar"><div className="search-box"><Search size={15} /><input type="search" placeholder="Search service, pattern, or lesson" value={query} onChange={(event) => searchMemory(event.target.value)} data-testid="input-search-memory" /></div><span className="eyebrow">{filtered.length} of {memories.length} memories</span></div><div id="memory-results" data-testid="memory-results"><div className="memory-gallery" id="memory-gallery" data-testid="memory-gallery">{filtered.length === 0 ? <div className="panel empty-state" style={{ gridColumn: '1 / -1' }}><Search size={25} /><div>No matching memory yet.</div><p style={{ fontSize: 11 }}>Try a service name like checkout-api or search for a lesson.</p></div> : filtered.map((memory) => <article className="memory-card fade-in-up" data-severity={memory.severity} key={memory.id} data-testid={`memory-card-${memory.id}`}><div className="memory-card-top"><span className="service-pill">{memory.service}</span><span className={`severity-dot severity-${memory.severity.toLowerCase()}`} title={memory.severity} /></div><h3>{memory.title}</h3><p>{memory.summary}</p><div className="memory-lessons"><span>Lesson learned</span><p>{memory.lesson}</p></div><div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 15, color: 'hsl(var(--muted-foreground))', font: '10px var(--app-font-mono)' }}><TrendingUp size={12} /> recalled {memory.hits} times</div></article>)}</div></div></div>;
}

function ResolveModal({ incident, onClose, onSubmit }: { incident: Incident; onClose: () => void; onSubmit: (rootCause: string, resolution: string, lesson: string) => void }) {
  const [step, setStep] = useState(1);
  const [rootCause, setRootCause] = useState('');
  const [resolution, setResolution] = useState('');
  const [lesson, setLesson] = useState('');
  const submitResolve = () => { if (step < 4) { setStep(step + 1); return; } onSubmit(rootCause, resolution, lesson); };
  return <div className="modal-backdrop" id="resolve-modal" role="dialog" aria-modal="true" aria-labelledby="resolve-modal-title" data-testid="resolve-modal"><div className="modal"><div className="modal-header"><div><div className="eyebrow">Close incident / retain learning</div><h2 id="resolve-modal-title">{incident.title}</h2></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close resolve modal" data-testid="button-close-resolve-modal"><X size={16} /></button></div><div className="modal-content"><div className="stepper">{['Root cause', 'Resolution', 'Lessons', 'Retain memory'].map((label, index) => <div className={`step ${step >= index + 1 ? 'active' : ''}`} key={label}><div className="step-number">{step > index + 1 ? <Check size={12} /> : index + 1}</div><span>{label}</span></div>)}</div>{step === 1 && <div className="field"><label htmlFor="resolve-root-cause">What was the root cause?</label><textarea id="resolve-root-cause" value={rootCause} onChange={(event) => setRootCause(event.target.value)} placeholder="e.g. A connection pool was exhausted after the deploy changed request fan-out." data-testid="textarea-root-cause" /></div>}{step === 2 && <div className="field"><label htmlFor="resolve-resolution">What fixed it?</label><textarea id="resolve-resolution" value={resolution} onChange={(event) => setResolution(event.target.value)} placeholder="Describe the action that restored service." data-testid="textarea-resolution" /></div>}{step === 3 && <div className="field"><label htmlFor="resolve-lesson">What should the agent remember?</label><textarea id="resolve-lesson" value={lesson} onChange={(event) => setLesson(event.target.value)} placeholder="Make this useful for the next on-call." data-testid="textarea-lesson" /></div>}{step === 4 && <div style={{ textAlign: 'center', padding: '12px 0 20px' }}><div className="stat-icon" style={{ margin: '0 auto 15px', width: 48, height: 48 }}><BrainCircuit size={24} /></div><div className="panel-title">Ready to make this operational memory?</div><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: 12, lineHeight: 1.6, maxWidth: 370, margin: '8px auto 0' }}>This resolution will be available to the agent the next time a similar signal appears.</p></div>}</div><div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={step === 1 ? onClose : () => setStep(step - 1)} data-testid="button-back-resolve">{step === 1 ? 'Cancel' : 'Back'}</button><button type="button" className="btn btn-primary" onClick={submitResolve} disabled={step === 1 && !rootCause.trim() || step === 2 && !resolution.trim() || step === 3 && !lesson.trim()} data-testid="button-submit-resolve">{step < 4 ? 'Continue' : 'Retain memory'} <ArrowRight size={14} /></button></div></div></div>;
}

function IncidentIQ() {
  const [location, setLocation] = useLocation();
  const active = getView(location);
  const [collapsed, setCollapsed] = useState(false);
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [memories, setMemories] = useState<Memory[]>(initialMemories);
  const [memoryHits, setMemoryHits] = useState(47);
  const [resolveIncident, setResolveIncident] = useState<Incident | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (message: string) => { setToast(message); window.setTimeout(() => setToast(null), 3500); };
  const showTab = (view: View) => { setLocation(view === 'dashboard' ? '/' : `/${view}`); };
  const submitIncident = (data: Omit<Incident, 'id' | 'time' | 'status'>) => { setIncidents((current) => [{ ...data, id: `inc-${Date.now()}`, time: 'just now', status: 'Investigating' }, ...current]); showToast('Incident received — 3 memories recalled'); };
  const openResolveModal = (incident: Incident) => setResolveIncident(incident);
  const submitResolve = (_rootCause: string, _resolution: string, lesson: string) => { if (!resolveIncident) return; setIncidents((current) => current.map((incident) => incident.id === resolveIncident.id ? { ...incident, status: 'Resolved', time: 'just now' } : incident)); setMemories((current) => [{ id: `mem-${Date.now()}`, title: resolveIncident.title, service: resolveIncident.service, severity: resolveIncident.severity, summary: resolveIncident.description, lesson: lesson || 'Keep the first guardrail close to the signal.', hits: 0 }, ...current]); setResolveIncident(null); showToast('Resolved — a new memory is now active'); };
  const seedMemory = () => { setMemories((current) => [{ id: `mem-${Date.now()}`, title: 'Cache stampede after cold start', service: 'catalog-db', severity: 'P2', summary: 'A cold cache caused synchronized reads to overload the primary database.', lesson: 'Warm the hottest keys before shifting traffic to a cold cluster.', hits: 1 }, ...current]); showToast('Demo memory seeded — the agent just learned something new'); };
  const searchMemory = (_query: string) => { if (_query.length > 2) setMemoryHits((hits) => hits + 1); };
  useEffect(() => { const move = (event: MouseEvent) => { const glow = document.querySelector<HTMLElement>('.cursor-glow'); if (glow) { glow.style.left = `${event.clientX}px`; glow.style.top = `${event.clientY}px`; } }; window.addEventListener('mousemove', move); return () => window.removeEventListener('mousemove', move); }, []);
  const renderView = (): ReactNode => {
    if (active === 'new-incident') return <NewIncident onSubmit={submitIncident} onNavigate={showTab} />;
    if (active === 'before-after') return <Comparison onNavigate={showTab} />;
    if (active === 'memory') return <MemoryPage memories={memories} onSeed={seedMemory} onSearch={searchMemory} />;
    return <Dashboard incidents={incidents} memories={memories} onNavigate={showTab} onResolve={openResolveModal} memoryHits={memoryHits} />;
  };
  return <div className="app-shell dark"><div className="top-line" /><div className="aurora"><span className="one" /><span className="two" /><span className="three" /></div><div className="grain" /><div className="cursor-glow" /><div className="shell-grid" style={{ gridTemplateColumns: collapsed ? '78px minmax(0, 1fr)' : undefined }}><ShellNav active={active} onNavigate={showTab} collapsed={collapsed} onToggle={() => setCollapsed((value) => !value)} /><main className="main"><Header active={active} onNavigate={showTab} onNew={() => showTab('new-incident')} />{renderView()}</main></div>{resolveIncident && <ResolveModal incident={resolveIncident} onClose={() => setResolveIncident(null)} onSubmit={submitResolve} />}{toast && <div className="toast" id="toast" role="status" data-testid="toast"><Check size={16} /><span>{toast}</span><span className="toast-progress" /></div>}</div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={IncidentIQ} /><Route path="/new-incident" component={IncidentIQ} /><Route path="/before-after" component={IncidentIQ} /><Route path="/memory" component={IncidentIQ} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;